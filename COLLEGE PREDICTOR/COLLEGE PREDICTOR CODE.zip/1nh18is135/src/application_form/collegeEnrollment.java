package application_form;

import java.util.List;
public abstract class collegeEnrollment {
    protected abstract List<String> getExamsList();
}

