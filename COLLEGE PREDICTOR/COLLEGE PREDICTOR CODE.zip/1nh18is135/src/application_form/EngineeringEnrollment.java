package application_form;

import java.util.ArrayList;
import java.util.List;

public class EngineeringEnrollment extends collegeEnrollment{
    
    
    @Override
    public List<String> getExamsList() {
        List<String> examsList = new ArrayList<>();
        examsList.add("EAMCET");
        examsList.add("MAINS");
        examsList.add("IPE");
        examsList.add("ADVANCED");
        examsList.add("C-EXAM");
        return examsList;
    }
}



