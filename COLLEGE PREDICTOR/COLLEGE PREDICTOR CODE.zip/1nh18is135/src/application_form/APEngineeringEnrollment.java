package application_form;

import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class APEngineeringEnrollment extends EngineeringEnrollment{
    
    private List<String> getListOfChoices(String exam, Integer marks) {
        List<String> choices = new ArrayList<>();
        switch (exam) {
						case "EAMCET":
							if (marks > 80) {
								choices.add("CSE");
								choices.add("ECE");
								choices.add("MECHANICAL");
								choices.add("ECM");
							} else {
								choices.add("CIVIL");
								choices.add("BIOTECHNOLOGY");
								choices.add("EEE");
							}
							break;
						case "MAINS":
							if (marks > 90) {
								choices.add("CSE");
								choices.add("ECE");
								choices.add("MECHANICAL");
								choices.add("ECM");
							} else {
								choices.add("CIVIL");
								choices.add("BIOTECHNOLOGY");
								choices.add("EEE");
							}
							break;
						case "IPE":
							if (marks > 900) {
								choices.add("CSE");
								choices.add("ECE");
								choices.add("MECHANICAL");
								choices.add("ECM");
							} else {
								choices.add("CIVIL");
								choices.add("BIOTECHNOLOGY");
								choices.add("EEE");
							}
							break;
						case "ADVANCED":
							if (marks > 100) {
								choices.add("CSE");
								choices.add("ECE");
								choices.add("MECHANICAL");
								choices.add("ECM");
								choices.add("AEROSPACE");
							} else {
								choices.add("CIVIL");
								choices.add("BIOTECHNOLOGY");
								choices.add("EEE");
							}
							break;
						default:
							choices = getListOfChoices(marks);
						}
        return choices;
    }
    
    private List<String> getListOfChoices(Integer marks) {
        List<String> choices = new ArrayList<>();
        if (marks > 200) {
            choices.add("CSE");
            choices.add("ECE");
            choices.add("MECHANICAL");
            choices.add("ECM");
        } else {
            choices.add("CIVIL");
            choices.add("BIOTECHNOLOGY");
            choices.add("EEE");
        }
        return choices;
    }
    
    private String getCollege(Integer marks) {
        if(marks < 190) {
            return "SSN College";
        }
        else if(marks < 220) {
            return "Rao and Naidu College";
        }
        else if(marks < 250) {
            return "Rise college";
        }
        else {
            return "Qis college";
        }
    }
	public static void main(String args[]) {
            
            APEngineeringEnrollment p = new APEngineeringEnrollment();
		JFrame frame = new JFrame("Admission Form");
		frame.setSize(600, 600);

		JLabel l1, l2;
		JButton btn1;

		l1 = new JLabel("Welcome!!!");
		l1.setFont(new Font("Serif", Font.BOLD, 30));
		l1.setForeground(Color.blue);

		l2 = new JLabel("Block your choice below");
		Choice c = new Choice();
                List<String> examsList =  p.getExamsList();
                for(String exam : examsList) {
                    c.add(exam);
                }

		btn1 = new JButton("Submit");

		btn1.setBackground(Color.green);

		l1.setBounds(100, 30, 400, 30);
		l2.setBounds(100, 100, 200, 30);
		c.setBounds(100, 140, 75, 75);

		btn1.setBounds(175, 175, 100, 30);

		frame.add(c);
		frame.add(l1);
		frame.add(l2);
		frame.add(btn1);

		frame.setLayout(null);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				JFrame f = new JFrame("MARKS");
				f.setSize(600, 600);

				Label label = new Label();
				String data = c.getItem(c.getSelectedIndex());
				String data0 = "Exam Selected: " + data;
				label.setText(data0 + "  Enter marks below");
				JButton btn2 = new JButton("Submit");
				JTextField jt1 = new JTextField(10);
				Label label1 = new Label(data);

				label1.setBounds(100, 100, 400, 100);
				label.setBounds(100, 100, 400, 100);
				jt1.setBounds(200, 200, 60, 30);
				btn2.setBounds(200, 300, 100, 30);

				f.add(label);
				f.add(jt1);
				f.add(btn2);

				f.setLayout(null);
				f.setVisible(true);
				f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

				btn2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						f.dispose();
						JFrame fr = new JFrame("CHOOSE BRANCH");
						fr.setSize(600, 600);

						String data1 = label1.getText();
						String marks = jt1.getText();
						int a = Integer.parseInt(marks);

						Choice ch = new Choice();
						JLabel l = new JLabel("CHOOSE A BRANCH");
						JButton b = new JButton("CLICK");

						b.setBounds(400, 400, 100, 30);
						ch.setBounds(250, 250, 100, 100);
						l.setBounds(100, 100, 200, 200);
                                                
                                                List<String> choicesList = p.getListOfChoices(data1, a);
                                                for(String choice : choicesList) {
                                                    ch.add(choice);
                                                }

						fr.add(ch);
						fr.add(l);
						fr.add(b);
						fr.setLayout(null);

						fr.setVisible(true);
						fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

						b.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								fr.dispose();
								JFrame jf = new JFrame("FILL THE DETAILS");
								jf.setSize(600, 600);

								JLabel name, age, fn, fo, mn, mo, dob, gen, payment;
								JTextField namei, agei, fni, foi, mni, moi, dobdi, dobmi, dobyi;
								Choice gender, pay;
                                                                
								name = new JLabel("NAME");
								age = new JLabel("AGE");
								gen = new JLabel("GENDER");
								fn = new JLabel("FATHER'S NAME");
								mn = new JLabel("MOTHER'S NAME");
								dob = new JLabel("DATE OF BIRTH");
								payment = new JLabel("PAYMENT");
                                                                
								namei = new JTextField(30);
								agei = new JTextField(3);
								dobdi = new JTextField(3);
								dobmi = new JTextField(3);
								dobyi = new JTextField(3);
								fni = new JTextField(30);
								mni = new JTextField(30);

								gender = new Choice();
								pay = new Choice();
								gender.add("MALE");
								gender.add("FEMALE");
								pay.add("CASH");
								pay.add("DD");
								pay.add("DEBIT CARD");

								name.setBounds(100, 100, 100, 20);
								namei.setBounds(200, 100, 190, 20);
								age.setBounds(100, 150, 100, 20);
								agei.setBounds(200, 150, 100, 20);
								dob.setBounds(100, 250, 100, 20);

								dobdi.setBounds(200, 250, 50, 20);
								dobmi.setBounds(250, 250, 50, 20);
								dobyi.setBounds(300, 250, 50, 20);
								gen.setBounds(100, 200, 100, 20);
								fn.setBounds(100, 300, 100, 20);
								fni.setBounds(250, 300, 100, 20);
								mn.setBounds(100, 350, 100, 20);
								mni.setBounds(250, 350, 100, 20);
								payment.setBounds(100, 400, 100, 20);

								gender.setBounds(200, 200, 70, 70);
								pay.setBounds(250, 400, 100, 100);
                                                                
								jf.add(name);
								jf.add(namei);
								jf.add(age);
								jf.add(agei);
								jf.add(dob);
								jf.add(dobdi);
								jf.add(dobmi);
								jf.add(dobyi);
								jf.add(gen);
								jf.add(gender);
								jf.add(fn);
								jf.add(fni);
								jf.add(mn);
								jf.add(mni);
								jf.add(payment);
								jf.add(pay);

								JButton but = new JButton("SUBMIT");
								but.setBounds(450, 500, 100, 30);
								jf.add(but);

								jf.setLayout(null);

								jf.setVisible(true);
								jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

								but.addActionListener(new ActionListener() {
									public void actionPerformed(ActionEvent e) {
										jf.dispose();
										JFrame finall = new JFrame("ADMISSION FORM");
										finall.setSize(600, 600);

										JLabel lab0 = new JLabel();
										JLabel lab1 = new JLabel();
										JLabel lab2 = new JLabel();
										JLabel lab3 = new JLabel();
										JLabel lab4 = new JLabel();
										JLabel lab5 = new JLabel();
										JLabel lab6 = new JLabel();
										JLabel lab7 = new JLabel();

										lab0.setText("College =" + p.getCollege(a));
										lab0.setBounds(100, 50, 300, 50);
										finall.add(lab0);

										lab1.setText("Name =" + namei.getText());
										lab1.setBounds(100, 100, 300, 50);
										finall.add(lab1);

										lab2.setText("Age =" + agei.getText());
										lab2.setBounds(100, 150, 300, 50);
										finall.add(lab2);

										lab3.setText("Date of Birth = " + dobdi.getText() + "-" + dobmi.getText() + "-"
												+ dobyi.getText());
										lab3.setBounds(100, 200, 300, 50);
										finall.add(lab3);

										lab4.setText("Father's name = " + fni.getText());
										lab4.setBounds(100, 250, 300, 50);
										finall.add(lab4);

										lab5.setText("Mother's name = " + mni.getText());
										lab5.setBounds(100, 300, 300, 50);
										finall.add(lab5);

										lab6.setText("Mode of Payment = " + pay.getItem(pay.getSelectedIndex()));
										lab6.setBounds(100, 350, 300, 50);
										finall.add(lab6);

										lab7.setText("Amount to be paid =  105000");
										lab7.setBounds(100, 400, 300, 50);
										finall.add(lab7);

										finall.setLayout(null);

										finall.setVisible(true);
										finall.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
										try {

											FileWriter fstream = new FileWriter(System.currentTimeMillis() + "out.txt");

											BufferedWriter out = new BufferedWriter(fstream);

											out.write("College = " + p.getCollege(a));
                                                                                          out.write("Name = " + namei.getText());
											out.write("Age = " + agei.getText());
											out.write("Date of Birth = " + dobdi.getText() + "-" + dobmi.getText() + "-"
													+ dobyi.getText());
											out.write("Gender = " + gender.getItem(gender.getSelectedIndex()));
											out.write("Father's name = " + fni.getText());
											out.write("Mother's name = " + mni.getText());
											out.write("Mode of Payment = " + pay.getItem(pay.getSelectedIndex()));
											out.write("Amount to be paid = 10500");

											out.close();

										} catch (Exception e1) {

											System.err.println("Error: " + e1.getMessage());

										}
									}
								});
							}
						});
					}
				});

			}

		});

	}

	}
	

	


